﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Ejercicio carita");
imprimirFiguras();


//Declarar variables
string _circulo, _rectangulo, _triangulo; 


void crearRectangulo(string v)
{
    _rectangulo = "  ********************************** \n" +
                  "  **********************************"; 
    Console.WriteLine(_rectangulo);

}


void crearTriangulo()
{
    _triangulo = "   *                           *    \n" +
                "   * *                         * *   \n" +
                "  *   *                       *   *  \n" +
                " *     *                     *     * \n" +
                " *******                     *******";
    Console.WriteLine(_triangulo);
}


void crearCirculo()
{
    _circulo = "              ****             \n" +
               "            **    **           \n" +
               "            **    **           \n" +
               "              ****             \n";
    Console.WriteLine(_circulo);  
}


void imprimirFiguras()
{
    crearTriangulo();
    crearCirculo();
    crearRectangulo
);



}

Console.ReadKey();
  
    

                 