﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("HOLA AMIKOS ");
Console.WriteLine("Ingrese su lista de 10 Palabras  ");
//* Recibir 10 palabras *// 
Console.WriteLine("Ingresar palabra 1 ");
String pablabra1 = Console.ReadLine();
Console.WriteLine("Ingresar palabra 2 ");
String pablabra2 = Console.ReadLine();
Console.WriteLine("Ingresar palabra 3 ");
String pablabra3 = Console.ReadLine();
Console.WriteLine("Ingresar palabra 4 ");
String pablabra4 = Console.ReadLine();
Console.WriteLine("Ingresar palabra 5 ");
String pablabra5 = Console.ReadLine();
Console.WriteLine("Ingresar palabra 6 ");
String pablabra6 = Console.ReadLine();
Console.WriteLine("Ingresar palabra 7 ");
String pablabra7 = Console.ReadLine();
Console.WriteLine("Ingresar palabra 8 ");
String pablabra8 = Console.ReadLine();
Console.WriteLine("Ingresar palabra 9 ");
String pablabra9 = Console.ReadLine();
Console.WriteLine("Ingresar palabra 10 ");
String pablabra10 = Console.ReadLine();


Console.ReadKey();